<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateManageWorkerTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('manage_worker', function (Blueprint $table) {
            $table->increments('mw_id');
            $table->integer('w_id');
            $table->integer('srv_id');
            $table->date('add_date');
            $table->string('jobtitle');
            $table->integer('e_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('manage_worker');
    }
}
