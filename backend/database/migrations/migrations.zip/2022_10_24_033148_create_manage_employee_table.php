<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateManageEmployeeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('manage_employee', function (Blueprint $table) {
            $table->increments('me_id');
            $table->integer('d_id');
            $table->date('add_date');
            $table->string('jobtitle');
            $table->integer('e_id');
            $table->integer('m_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('manage_employee');
    }
}
